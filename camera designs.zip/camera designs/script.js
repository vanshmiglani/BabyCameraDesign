const left = document.getElementById('a_left')
const right = document.getElementById('a_right')
const scroll = document.querySelector('.add')

left.addEventListener('click', ()=>{
    left.style.scrollBehavior = 'smooth'
    scroll.scrollTop-=20

})
right.addEventListener('click', ()=>{
    right.style.scrollBehavior = 'smooth'
    scroll.scrollTop +=20
})
scroll.addEventListener('wheel', (evt)=>{
    evt.preventDefault()
    scroll.style.scrollBehaviour = 'smooth'
    scroll.scrollTop += evt.deltaY
})